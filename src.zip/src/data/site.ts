/**
 * ALL the content of the site lives in this file.
 * Edit the text here; you should not need to touch the markup.
 */

export type Service = {
  title: string;
  description: string;
  /** Optional short bullet list shown under the description. */
  points?: string[];
};

export const site = {
  name: 'Scale for Earth',

  /** Short line shown above the name in the hero. */
  eyebrow: 'Earth Observation · Data Pipelines · Cloud',

  /** One-line promise under the name. */
  tagline: 'Earth Observation workflows that scale.',

  /** One or two sentences. */
  description:
    'TODO: Replace with a short description of what the company does and who it helps.',

  /** Page <title> and meta description (used by search engines and link previews). */
  seoTitle: 'Scale for Earth — Earth Observation Consulting',
  seoDescription:
    'TODO: One sentence (about 150 characters) describing the company for search results.',

  /**
   * Put your files in /public and reference them from the root, e.g. '/logo.svg'.
   * Leave as null to show a plain text wordmark / no hero image.
   */
  logo: '/logo-light.svg',
  logoDark: '/logo-dark.svg',
  logoAlt: 'Scale for Earth',
  heroImage: null as string | null, // e.g. '/hero.jpg'
  heroImageAlt: 'TODO: describe the image',
  /** Image used for link previews (LinkedIn, Slack, ...). 1200x630 works best. */
  ogImage: null as string | null, // e.g. '/og.jpg'

  /**
   * Colour palette. One of: 'ocean' | 'forest' | 'terra' | 'orbit'
   * (see src/styles/global.css to tweak or add your own).
   */
  palette: 'ocean' as 'ocean' | 'forest' | 'terra' | 'orbit',
} as const;

export const services = {
  heading: 'What we do',
  intro: 'TODO: One sentence introducing the services.',

  /**
   * How the services are displayed:
   *  'cards' - grid of cards (good for 3-6 items, with or without bullet points)
   *  'list'  - editorial rows, title left / text right (good for 3-8 items)
   *  'steps' - numbered sequence, reads like a workflow (good for 3-5 items)
   */
  layout: 'cards' as 'cards' | 'list' | 'steps',

  /**
   * Add, remove or reorder items freely: the page adapts to however many you list.
   * These are placeholders: rewrite them in your own words.
   */
  items: [
    {
      title: 'Satellite data pipelines',
      description:
        'TODO: Describe how you design and build pipelines that turn raw satellite imagery into analysis-ready data.',
      points: ['Placeholder point one', 'Placeholder point two'],
    },
    {
      title: 'Processing workflows',
      description:
        'TODO: Describe the processing, analysis or time-series work you deliver.',
      points: ['Placeholder point one', 'Placeholder point two'],
    },
    {
      title: 'Cloud-native infrastructure',
      description:
        'TODO: Describe how you deploy and operate these workflows in the cloud.',
      points: ['Placeholder point one', 'Placeholder point two'],
    },
  ] as Service[],
};

export const about = {
  /** Set show to false to hide the section completely. */
  show: true,
  heading: 'About',
  /** Each string becomes one paragraph. */
  paragraphs: [
    'TODO: A short bio: who you are, your background and what you focus on.',
  ],
};

export const contact = {
  heading: 'Get in touch',
  // intro: 'TODO: One line inviting people to reach out.',
  email: 'info@scaleforearth.com', // TODO: company email
  linkedin: {
    label: 'LinkedIn',
    url: 'https://www.linkedin.com/in/george-begkas/', // TODO: your profile URL
  },
  /** e.g. 'Based in Athens, Greece'. Leave empty to hide. */
  location: 'Based in Greece',
};

export const footer = {
  text: 'Earth Observation consulting.',
};
